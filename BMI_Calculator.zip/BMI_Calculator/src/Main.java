import javax.swing.*;
import java.text.DecimalFormat;

public class Main {

    public static void main(String[] args) {
        int weight=Integer.parseInt(JOptionPane.showInputDialog("Weight in kg?"));
        double uheight=Integer.parseInt(JOptionPane.showInputDialog("Height in cm?"));
        double height=uheight/100;
        System.out.println("weight"+weight+"\n"+"height"+height);

        DecimalFormat df = new DecimalFormat("0.00");
        double bmi=weight/(height*height);
        JOptionPane.showMessageDialog(null,"Your BMI is: "+df.format(bmi));
    }
}
